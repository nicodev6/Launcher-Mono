package pl.monolith.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var clock: TextView
    private val apps = mutableListOf<AppEntry>()
    private val white = Color.rgb(242, 242, 245)
    private val muted = Color.rgb(150, 150, 158)
    private val bg = Color.BLACK
    private val card = Color.rgb(18, 18, 21)

    data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        buildUi()
        loadApps()
        renderApps("")
        updateClock()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(22), dp(24), dp(22), dp(12))
        }

        val brand = TextView(this).apply {
            text = "M O N O L I T H"
            textSize = 20f
            letterSpacing = 0.12f
            setTextColor(white)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(42)))

        clock = TextView(this).apply {
            textSize = 34f
            setTextColor(white)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        root.addView(clock, LinearLayout.LayoutParams(-1, dp(48)))

        val subtitle = TextView(this).apply {
            text = "APLIKACJE  •  LIST MODE"
            textSize = 10f
            letterSpacing = 0.18f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(24)))

        search = EditText(this).apply {
            hint = "⌕   Szukaj aplikacji"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            singleLine = true
            background = rounded(card, dp(18), Color.rgb(55,55,60))
            setPadding(dp(16), 0, dp(16), 0)
        }
        val searchParams = LinearLayout.LayoutParams(-1, dp(52))
        searchParams.topMargin = dp(14)
        root.addView(search, searchParams)

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        val scrollParams = LinearLayout.LayoutParams(-1, 0, 1f)
        scrollParams.topMargin = dp(12)
        root.addView(scroll, scrollParams)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })

        setContentView(root)
    }

    private fun loadApps() {
        apps.clear()
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = packageManager.queryIntentActivities(intent, 0)
        for (ri in resolved) {
            val ai = ri.activityInfo
            if (ai.packageName == packageName) continue
            val label = ri.loadLabel(packageManager)?.toString() ?: ai.packageName
            val icon = ri.loadIcon(packageManager)
            apps.add(AppEntry(label, ai.packageName, icon))
        }
        apps.sortBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun renderApps(query: String) {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val filtered = apps.filter { it.label.contains(query, true) }
        var previousLetter = ""
        for (app in filtered) {
            val letter = app.label.firstOrNull()?.uppercaseChar()?.toString() ?: "#"
            if (query.isBlank() && letter != previousLetter) {
                val header = TextView(this).apply {
                    text = letter
                    textSize = 12f
                    setTextColor(muted)
                    letterSpacing = 0.15f
                    setPadding(dp(5), dp(10), 0, dp(4))
                }
                list.addView(header, LinearLayout.LayoutParams(-1, dp(28)))
                previousLetter = letter
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(card, dp(14), Color.rgb(35,35,39))
                setPadding(dp(12), dp(8), dp(14), dp(8))
            }
            val icon = ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(34), dp(34)))
            val name = TextView(this).apply {
                text = app.label
                textSize = 15f
                setTextColor(white)
                setPadding(dp(14), 0, 0, 0)
                maxLines = 1
            }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val arrow = TextView(this).apply {
                text = "›"
                textSize = 24f
                setTextColor(muted)
            }
            row.addView(arrow)

            row.setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launch)
                }
            }
            val lp = LinearLayout.LayoutParams(-1, dp(54))
            lp.bottomMargin = dp(5)
            list.addView(row, lp)
        }
        if (filtered.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Nie znaleziono aplikacji"
                setTextColor(muted)
                gravity = Gravity.CENTER
                textSize = 14f
                setPadding(0, dp(30), 0, dp(30))
            }
            list.addView(empty)
        }
    }

    private fun updateClock() {
        val now = Date()
        val time = SimpleDateFormat("HH:mm", Locale("pl", "PL")).format(now)
        val date = SimpleDateFormat("EEEE, d MMMM", Locale("pl", "PL")).format(now)
        clock.text = "$time\n${date.replaceFirstChar { it.uppercase() }}"
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
